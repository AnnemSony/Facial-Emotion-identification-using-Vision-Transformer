In order to run the code we first need to pass the require dataset i.e smile and non- smile dataset.
it were downloaded from kaggle repository.
Use google collab to run the code.


At the end i perfomed cnn algoithm to check the difference in between the vit and cnn
